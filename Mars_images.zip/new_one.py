from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def colonization():
    return '<h1>Миссия Колонизация Марса</h1>'


@app.route('/index')
def mars():
    return '<h1>И на Марсе будут яблони цвести!</h1>'


@app.route('/promotion')
def add_company():
    return '''
Человечество вырастает из детства.</br>
Человечеству мала одна планета.</br>
Мы сделаем обитаемыми безжизненные пока планеты.</br>
И начнем с Марса!</br>
Присоединяйся!</br>
'''


@app.route('/sample_page')
def return_sample_page():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Привет, Яндекс!</title>
                  </head>
                  <body>
                    <h1>Первая HTML-страница</h1>
                  </body>
                </html>
            """


@app.route('/promotion_image')
def bootstrap():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
                    crossorigin="anonymous">
                    <link rel="stylesheet" type="text/css" href="/static/css/style.css" />
                    <title>Колонизация</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="/static/img/mars.jpg" alt="здесь должна была быть картинка, но не нашлась">
                    <div class="alert alert-primary" role="alert"><p>Человечество вырастает из детства.</p></div>
                    <div class="alert alert-success"><p>Человечеству мала одна планета.</p></div>
                    <div class="alert alert-warning"><p>Мы сделаем обитаемыми безжизненные пока планеты.</p></div>
                    <div class="alert alert-danger"><p>И начнем с Марса!</p></div>
                    <div class="alert alert-info"><p>Присоединяйся!</p></div>
                  </body>
                </html>'''


@app.route('/form_sample', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="en">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                            integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                            <title>Отбор астронавтов</title>
                          </head>
                          <body>
                            <h1 align='center'>Анкета претиндента</h1></br>
                            <h2 align='center'>на участие в миссии</h2>
                            <div>
                                <form class="login_form" method="post">
                                    <input type="text" class="form-control" id="surname" placeholder="Введите фамилию" name="surname">
                                    <input type="text" class="form-control" id="name" placeholder="Введите имя" name="name"></br>
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
                                    <div class="form-group">
                                        <label for="classSelect">Какое у Вас образование?</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>начальное</option>
                                          <option>среднее</option>
                                          <option selected>высшее</option>
                                          <option>вообще нет :(</option>
                                        </select>
                                     </div>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work1">
                                            инженер-исследователь</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work2">
                                            пилот</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work3">
                                            строитель</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work4">
                                             киберинженер</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work5">
                                            врач</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work6">
                                             инженер жизнеобеспечения</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work7">
                                            пилот дронов</br>
                                          <input class="form-check-input" type="checkbox" name="sex" id="male" value="work8">
                                             штурман</br>
                                        </div>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                            Мужской
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                            Женский
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="about">Почему Вы хотите принять участие в миссии?</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                        <img src=photo>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">Готовы остаться на марсе?</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Отправить</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        return "Форма отправлена. Мы рассмотрим ее и ответим вам. Марс ждет!"


@app.route('/choice/<planet_name>')
def greeting(planet_name):
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                   <link rel="stylesheet"
                   href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                   integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                   crossorigin="anonymous">
                    <title>Варианты выбора</title>
                  </head>
                  <body>
                    <h1>Мое предложение: {}</h1>
                    <h3>Эта планета близка к Земле;</h3>
                    <div class="alert alert-success"><p>На ней есть много необходимых ресурсов;</p></div>
                    <div class="alert alert-warning"><p>На ней есть вода и атмосфера;</p></div>
                    <div class="alert alert-danger"><p>На ней есть небольшое магнитное поле;</p></div>
                    <div class="alert alert-info"><p>Она очень красива!</p></div>
                  </body>
                </html>'''.format(planet_name, planet_name)


@app.route('/results/<nickname>/<int:level>/<float:rating>')
def three_params(nickname, level, rating):
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet"
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Результаты</title>
                  </head>
                  <body>
                    <h1>Результаты отбора</h1>
                    <h2>Претендента на участие в миссии {}:</h2>
                    <div class="alert alert-success"><h2>Поздравляем! Ваш рейтинг после {} этапа отбора</h2></div>
                    <div><h2>Составляет {}!</h2></div>
                    <div class="alert alert-warning"><h2>Желаем удачи!</h2></div>
                  </body>
                </html>'''.format(nickname, level, rating)


@app.route('/carousel')
def carousel():
    return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <title>Пейзажи Марса</title>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
              <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
            </head>
            <body>
            
            <div class="container">
              <h1 align='center'>Пейзажи Марса</h1>
              <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>
            
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
            
                  <div class="item active">
                    <img src=/static/img/mars1.jpg alt="Марс" style="width:100%;">
                    <div class="carousel-caption">
                    </div>
                  </div>
            
                  <div class="item">
                    <img src=/static/img/mars2.jpg alt="Марс" style="width:100%;">
                    <div class="carousel-caption">
                    </div>
                  </div>
                
                  <div class="item">
                    <img src=/static/img/mars3.jpg alt="Марс" style="width:100%;">
                    <div class="carousel-caption">
                    </div>
                  </div>
                </div>
                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
            </div>
            </body>
            </html>

        """


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
    #  http://127.0.0.1:8080/carousel
    #  '/static/img/mars.jpg'
